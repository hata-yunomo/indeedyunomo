#ifndef _METRICREGROUP_H_
#define _METRICREGROUP_H_

#include <stdint.h>

void calculateGroups(uint32_t, uint32_t, uint64_t, uint32_t, uint32_t, uint32_t*, uint32_t*);

uint64_t getMagicNumber(uint32_t);

#endif